from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# =============================
# Load model assets
# =============================
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "model"

model = joblib.load(MODEL_DIR / "unified_qsar_model.pkl")
scaler = joblib.load(MODEL_DIR / "scaler.pkl")

with open(MODEL_DIR / "feature_order.txt") as f:
    FEATURES = [line.strip() for line in f.readlines()]

# Oxidant → Redox potential
OXIDANT_E0_MAP = {
    "OH": 2.80,
    "NO3": 2.40,
    "O3": 2.07
}

# =============================
# Routes
# =============================

@app.route("/")
def welcome():
    return render_template("welcome.html")


@app.route("/predict", methods=["GET", "POST"])
def predict():
    prediction = None

    if request.method == "POST":
        oxidant = request.form["oxidant"]
        e0 = OXIDANT_E0_MAP[oxidant]

        values = []
        for feat in FEATURES:
            if feat == "Oxidant_E0":
                values.append(e0)
            else:
                values.append(float(request.form[feat]))

        X = np.array(values).reshape(1, -1)
        X = scaler.transform(X)
        prediction = float(model.predict(X)[0])

    return render_template(
        "predict.html",
        features=FEATURES,
        prediction=prediction
    )


if __name__ == "__main__":
    app.run(debug=True)